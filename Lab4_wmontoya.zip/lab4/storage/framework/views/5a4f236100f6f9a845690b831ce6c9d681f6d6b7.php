
<?php $__env->startSection('titulo', 'Laboratorio 2'); ?>
<?php $__env->startSection('contenido'); ?>

<div class="col-5 p-5 text-center">

    <div class="card">
        <div class="card-header">
            <h2>Login</h2>
        </div>
        <div class="card-body">
        <img src="img/key.svg" class="w-50 h-50">
            <form method="post" id="frm_inicio" name="frm_inicio" action="<?php echo e(route('IniciarSesion')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label">Usuario:</label>
                    <input type="text" class="form-control"  value="" tabindex="1" id="txt_user" name="txt_user">
                </div>
                <div class="mb-3">
                    <label class="form-label">Contrase&ntilde;a:</label>
                    <input type="password" class="form-control" value="" tabindex="2" id="txt_pass" name="txt_pass">
                </div>
                
                <?php if(isset($mensaje)): ?>
                <div class="alert alert-danger" role="alert">
                <?php echo e($mensaje); ?>

                </div>
               
                <?php endif; ?>
                <input type="submit" class="btn btn-primary" value="Entrar" name="btn_entrar" tabindex="3">
            </form>

         

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lab4\resources\views/plantillas/inicio_sesion.blade.php ENDPATH**/ ?>